#' Hello, World!
#'
#' This function prints a simple greeting.
#'
#' @examples hello()
hello <- function() {
  print("Hello, world!")
}
hello()
